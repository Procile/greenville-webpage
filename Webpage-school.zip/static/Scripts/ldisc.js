// Module:       ldisc.js
//
// Synopsis:     Function warning() to redirect to an asp page named disclaimer.asp which
//               displays a message before redirecting to an external link.
//
// Usage:        <a href="http://mydomain.com" onclick="return warning(this)">Click</a>
//
// Installation: Place in the <head></head> section the following code snipet
//               <script type="text/javascript" src="/Scripts/ldisc.js"></script>

function warning(url)
{
    if(url.hostname == '')
    {
        return false;
    }
    if(url.search.indexOf('URL') == 1)
    {     	
        url.href = '/Disclaimer.aspx' +  '?URL' + url.search.substr(4);
    }
    else
    {
        url.href = '/Disclaimer.aspx' +  '?URL=' + url.href;
    }
    return true;
}
//-->