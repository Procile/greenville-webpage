// Module:       ldisc.js
//
// Synopsis:     Function warning() to redirect to an asp page named disclaimer.asp which
//               displays a message before redirecting to an external link.
//
// Usage:        <a href="http://mydomain.com" onclick="return warning(this)">Click</a>
//
// Installation: Place in the <head></head> section the following code snipet
//              

function warning2(url)
{
    if(url.hostname == '')
    {
        return false;
    }
    if(url.search.indexOf('URL') == 1)
    {     	
        url.href = '/Disclaim.aspx' +  '?URL' + url.search.substr(4);
    }
    else
    {
        url.href = '/Disclaim.aspx' +  '?URL=' + url.href;
    }
    return true;
}
//-->